# CMU-CS-Academy-Answers
This is for the 3rd edition of the program, however, other editions likely have the majority of similar problems, especially units after 3.
