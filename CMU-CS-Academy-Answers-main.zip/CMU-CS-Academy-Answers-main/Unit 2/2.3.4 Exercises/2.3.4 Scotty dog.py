# background
app.background = 'lightGrey'

# Define the backlight variable.
### Place Your Code Here ###
backlight = Rect(0,0,400,50,fill='fireBrick')

# scotty dog
Polygon(130, 60, 150, 140, 150, 70, 170, 130, 260, 130, 220, 150, 325, 160,
        315, 260, 290, 240, 210, 240, 210, 270, 130, 205)
Polygon(125, 220, 208, 314, 180, 340, 80, 280)
Polygon(210, 270, 225, 274, 209, 256, fill=None, border='black')
Polygon(130, 205, 210, 270, 227, 276, 215, 320, 125, 220, fill=None,
        border='black')


def onMousePress(mouseX, mouseY):
    backlight.height=mouseY+1
    pass
