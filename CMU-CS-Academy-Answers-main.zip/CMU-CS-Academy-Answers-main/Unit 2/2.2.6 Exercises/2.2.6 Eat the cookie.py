# background
Rect(0, 0, 400, 400, fill='lightSteelBlue')

# cookie
Circle(205, 205, 155, fill='saddleBrown')
Circle(200, 200, 150, fill='peru')

def drawChocoChips(centerX, centerY):
    Circle(centerX, centerY, 10, fill=rgb(90, 35, 15))

# chocolate chips
drawChocoChips(140, 90)
drawChocoChips(215, 150)
drawChocoChips(275, 100)
drawChocoChips(315, 200)
drawChocoChips(270, 300)
drawChocoChips(230, 240)
drawChocoChips(150, 315)
drawChocoChips(150, 245)
drawChocoChips(80, 220)
drawChocoChips(120, 155)
drawChocoChips(190, 200)


def onMouseRelease(mouseX, mouseY):
    Circle(mouseX,mouseY,40,fill='lightSteelBlue')
    pass
