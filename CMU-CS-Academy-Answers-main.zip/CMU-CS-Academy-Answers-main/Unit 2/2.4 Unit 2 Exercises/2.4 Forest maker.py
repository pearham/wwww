# background
Rect(0, 0, 400, 400, fill=rgb(30, 58, 19))

def onMousePress(mouseX, mouseY):
    Rect(mouseX-5,mouseY+8,10,15,fill=gradient('sienna', rgb(120,50,30), start='top'))
    RegularPolygon(mouseX, mouseY,20,3,fill=gradient('green', rgb(0,80,0), start='top'))
    RegularPolygon(mouseX,mouseY-15,15,3,fill=gradient('lightGreen','DarkGreen',start='top'))
    pass
