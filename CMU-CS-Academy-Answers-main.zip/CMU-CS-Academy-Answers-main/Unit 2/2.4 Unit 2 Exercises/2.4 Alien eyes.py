app.background = gradient('black', 'midnightBlue', start='top')

Circle(200,200,100,fill='limeGreen')
Circle(100,200,20,fill='limeGreen')
Circle(150,290,20,fill='limeGreen')
Circle(250,290,20,fill='limeGreen')
Circle(300,200,20,fill='limeGreen')
Circle(200,245,25,fill='black')

Rect(175,220,50,25,fill='limeGreen')

# Write a function that draws one eye.
def drawEye(centerX, centerY, eyeSize, pupilSize):
    Circle(centerX,centerY,eyeSize,fill='white')
    Circle(centerX,centerY,pupilSize)
    pass

##### Place your code above this line, code below is for testing purposes #####
# test case:
drawEye(200, 175, 55, 27)
