app.background = 'red'

# mask ridges
Line(0, 0, 400, 400)
Line(400, 0, 0, 400)
Line(200, 0, 200, 400)
Line(0, 200, 400, 200)
Star(200, 200, 150, 9, fill=None, border='black', roundness=90)
Star(200, 200, 25, 9, fill=None, border='black', roundness=90)
Star(200, 200, 250, 9, fill=None, border='black', roundness=90)

# eyes
Oval(100, 150, 100, 200, fill='white', border='black', borderWidth=6,
     rotateAngle=-20)
Oval(300, 150, 100, 200, fill='white', border='black', borderWidth=6,
     rotateAngle=20)

def onMousePress(mouseX, mouseY):
    app.background='black'
    pass

def onMouseRelease(mouseX, mouseY):
    app.background='red'
    pass
