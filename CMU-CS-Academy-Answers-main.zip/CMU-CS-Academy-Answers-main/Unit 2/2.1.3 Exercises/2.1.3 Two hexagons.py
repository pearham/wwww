def drawTwoHexagons(color):
    RegularPolygon(200,100,100,6, fill=color)
    RegularPolygon(200,300,100,6, border=color, borderWidth=8, fill=None)
    pass

##### Place your code above this line, code below is for testing purposes #####
# test case:
drawTwoHexagons('green')
