# sky
Rect(0, 0, 400, 400, fill=gradient('dodgerBlue', 'salmon', start='top'))

# grass
Rect(0, 350, 400, 50, fill=gradient('lawnGreen', 'darkGreen', start='top'))

def drawFlower(points):
    # flower stem
    Line(200, 200, 200, 350, fill='lawnGreen', lineWidth=10)

    Star(200,200,60,points, fill=gradient('magenta','darkViolet','royalBlue'))
    Circle(200,200,20, fill=gradient('yellow','gold'))
    # draw a circle on top of the star for the flower's center.
    ### Place Your Code Here ###
    pass

##### Place your code above this line, code below is for testing purposes #####
# test case:
drawFlower(9)
