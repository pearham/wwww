These are the exercises/quizzes missing from UNIT 7:

Normal quiz, practise quiz