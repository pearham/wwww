These are the exercises/quizzes missing from UNIT 8:

Tower, kitchen table, tumbleweed, caterpillar, bubble maker, arm, asteroid orbit

SIDENOTE: Since CMU released the 4th edition it may be possible that your teacher will have their quizzes set to a completely new or random set of questions and answers.