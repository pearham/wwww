#This is a plinko game
#The ball begins from a random point, and the background changes every game
#Essentially its a random odd game, you click the space bar



#Design
Label("Welcome To Plinko!️", 200,40, size=36, bold=True)
Line(46,60,355,60)

#help menu
help_button_image = "https://cdn.discordapp.com/attachments/1129239902714867802/1134194458578137281/plswork1.png"
Image(help_button_image, 25,200)
Label('Press H for help!',55,270,fill='black',size=13)
g = Rect(40,40,325,325, fill='white')
l1=Label('Help Menu!',200,80,fill='black',size=13)
l2=Label('Simply Press the space bar and hope for the best!', 200,200,size=13,bold=True)
l3=Label('By Nick and Wanxin', 200,250,size=13,bold=True)
g.visible=False
l1.visible=False
l2.visible=False
l3.visible=False


def showMenu():
    g.visible=True
    l1.visible=True
    l2.visible=True
    l3.visible=True
    g.toFront()
    l1.toFront()
    l2.toFront()
    l3.toFront()
    


def onKeyRelease(key):
    if('h' in key):
        g.visible=False
        l1.visible=False
        l2.visible=False
        l3.visible=False
    
    

#setting up the background color randomizer to make the game pop more
color2 = randrange(0,256)
color3 = randrange(0,256)

#sets the background color, based on one fixed, and two random rgb values
app.background = rgb(255,color2,color3)

ball = Circle(200,50,5,fill='lime')

#ball positioning
ball.centerX = randrange(135,318)
ball.centerY = 110
ball.ballRadius=ball.radius
ball.toFront()

#direction of the ball
ball.dy = 0
ball.dx = 0

grid = Group()
border = Group(Rect(110,90,240,280,fill=None,border='black'))

#creating plinko sticks
num_rows = 5
num_sticks_per_row = [4,5,4,3,2]
sticks = []
for row in range(num_rows):
    num_sticks = num_sticks_per_row[row]
    row_width=num_sticks*37
    xValue = (230 - row_width) / 2
    for i in range(num_sticks_per_row[row]):
        x=135+xValue+i*37
        y=140+row*45
        stick=Circle(x,y,3)
        sticks.append(stick)
        grid.add(stick)

#setting up coins
coins = []
for x in range(120,381,44):
    coin = Circle(x,350,8,fill='gold',border='yellow')
    coins.append(coin)


coinsToWin=15
score = Label('Coins:0',50,120,fill='black',size=13)

#handles ball being dropped
def dropBall():
    ball.dy =-3.0
    ball.dx = 5
    
def onKeyPress(key):
    if('space' in key):
        if ball.dy == 0 and ball.dx == 0:
            dropBall()
    elif('h' in key):
        showMenu()

#onStep function

def onStep():

    ball.centerY-=ball.dy 
    ball.centerX+=ball.dx
    
    #checks if the ball reaches the bottom
    if ball.centerY>=385:
         ball.dy=0
         ball.dx=-3+6*random() 
         ball.centerY=110
         ball.centerX=randrange(135,318)
    #checks if the ball hits the top and ensures that the ball can move both ways
    if ball.centerY<90:
        ball.dy =-3.0
        ball.dx = -5 if randrange(2) == 0 else 5
        
    #ensures the ball doesnt go out of boundries
    if ball.centerX <= 110 or ball.centerX >=340:
        ball.dx=-ball.dx
    
    #check if the ball is blocked
    ball_blocked_below = False
    for stick in sticks:
        if ball.centerY+ball.radius>=stick.centerY and stick.left <= ball.centerX <= stick.right:
            ball_blocked_below=True
            break
        
    #ensure that the ball can get unstuck
    if ball_blocked_below:
        if ball.dx > 0:
            ball.dy=abs(ball.dy)
            ball.dx=5
        else:
            ball.dy=abs(ball.dy)
            ball.dx=-5

        
    elif ball.bottom >= border.bottom:
        ball.dy=-abs(ball.dy)
    
    #checks stick collisions
    for stick in sticks:
        if ball.hitsShape(stick):
            if ball.centerY<stick.centerY:
                ball.dy=abs(ball.dy)
            elif ball.centerY>stick.centerY:
                ball.dy=-abs(ball.dy)
            else: 
                ball.dy
                
            if ball.centerX<stick.centerX:
                ball.dx=-abs(ball.dx)
            elif ball.centerX>stick.centerX:
                ball.dx=abs(ball.dx)

    #checks coin collisions        
    for coin in coins:
        if ball.hitsShape(coin):
            coins_collected=0
            cointsToWin=15
            coins_collected+=1
            score.value='Coins: '+ str(coins_collected)
            
            if coins_collected >= cointsToWin:
                gameOver()
    
ball.toFront()

#game over (only called if all 15 points are claimed, cant lose!!!)
def gameOver():
    app.paused = True
    Label('Congratulations! You won!',200,200,size=30)
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                