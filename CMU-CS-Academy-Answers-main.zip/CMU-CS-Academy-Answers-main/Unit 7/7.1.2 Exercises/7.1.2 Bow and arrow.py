# background
Rect(0, 0, 400, 300, fill=gradient('lightSkyBlue', 'lightCyan', start='top'))
Rect(0, 300, 400, 100, fill=gradient('seaGreen', 'darkOliveGreen', start='top'))

# points
Label('Score:', 10, 25, size=24, align='left')
score = Label(0, 110, 26, size=28)

# stick person
Circle(80, 220, 20)
Line(80, 220, 80, 330, lineWidth=3)
Line(80, 330, 100, 380, lineWidth=3)
Line(80, 330, 60, 380, lineWidth=3)
leftArm = Line(80, 255, 100, 280, lineWidth=3)
rightArm = Line(80, 255, 125, 280, lineWidth=3)

# target
target = Group(
    Line(325, 265, 310, 302, fill='burlyWood'),
    Line(325, 265, 340, 302, fill='burlyWood'),
    Circle(325, 265, 25, fill='burlyWood'),
    Circle(325, 265, 22, fill='ghostWhite'),
    Circle(325, 265, 15, fill='crimson', border='deepSkyBlue', borderWidth=7),
    Circle(325, 265, 3, fill='yellow')
    )

# bow and arrow
### (HINT: The bow is defined as an arc!)
bow = Arc(100, 280, 50, 160, 0, 180, fill=None,
          border=gradient('saddleBrown', 'burlyWood', start='left'), borderWidth=5)

arrow = Line(100, 280, 200, 280, lineWidth=3, arrowEnd=True,
             fill=gradient('lightGrey', 'saddleBrown', start='right'))

def resetArrow():
    arrow.rotateAngle = 0
    arrow.x1 = 100
    arrow.y1 = 280
    arrow.x2 = 200
    arrow.y2 = 280
    arrow.lineWidth = 3
    leftArm.x2 = arrow.left

def resetBow():
    bow.startAngle = 0
    bow.sweepAngle = 180
    bow.width = 25
    bow.right = 125

def onMousePress(mouseX, mouseY):
    resetArrow()

def onMouseRelease(mouseX, mouseY):
    arrow.width = 30
    arrow.lineWidth = 1

    if (bow.sweepAngle < 130):
        arrow.right = 325
        arrow.centerY = 265
        score.value += 10
    elif (arrow.centerX < 150):
        arrow.rotateAngle = 30
        arrow.right = 300
        arrow.bottom = 310

    resetBow()

def onMouseDrag(mouseX, mouseY):
    if (bow.sweepAngle >= 125):
        # Pull back the arrow and increase the startAngle of the bow. Then decrease
        # the sweepAngle of the bow and increase the width and keep the right of
        # the bow in the same place.
        ### (HINT: Use the test cases to determine how much to change the
        #          properties.)
        ### Place Your Code Here ###
        bow.sweepAngle-=2
        bow.startAngle+=1
        bow.centerX-=2
        arrow.centerX-=2
        bow.width+=2
        # Moves the left arm.
        leftArm.x2 = arrow.left

def onKeyPress(key):
    # Do not change this function! It is for testing purposes only!
    if (key == 'q'):
        arrow.left = 56
        bow.startAngle = 22
        bow.sweepAngle = 136
        bow.width = 69
        bow.right = 125
        leftArm.x2 = arrow.left
