app.background = 'paleGreen'

track = Rect(200, 200, 360, 360, align='center')
innerGrass = Rect(200, 200, 260, 260, fill='paleGreen', align='center')
Rect(200, 200, 310, 310, fill=None, border='white', dashes=True, align='center')

message = Label('Dot Race!', 200, 200, size=25)

finishLine = Line(320, 200, 390, 200, fill='white', lineWidth=30)
Line(315, 200, 390, 200, fill='red', lineWidth=30, dashes=True)

purpleDot = Circle(45, 175, 15, fill='darkOrchid')
blueDot = Circle(45, 225, 15, fill='dodgerBlue')

def onKeyHold(keys):
    # While the race is still going, move the dots and check if the race ends.
    if (message.value == 'Dot Race!'):
        if ('up' in keys):
            purpleDot.centerY -= 10
        if ('down' in keys):
            purpleDot.centerY += 10
        if ('left' in keys):
            purpleDot.centerX -= 10
        if ('right' in keys):
            purpleDot.centerX += 10
        if ('w' in keys):
            blueDot.centerY -= 10
        if ('s' in keys):
            blueDot.centerY += 10
        if ('a' in keys):
            blueDot.centerX -= 10
        if ('d' in keys):
            blueDot.centerX += 10
        if(innerGrass.contains(blueDot.centerX, blueDot.centerY) == True or track.contains(blueDot.centerX,blueDot.centerY)== False):
        
            message.value='Purple dot won!'
        if (innerGrass.contains(purpleDot.centerX,purpleDot.centerY)==True or track.contains(purpleDot.centerX,purpleDot.centerY)==False):
            message.value='Blue dot won!'
            
        if (blueDot.hitsShape(finishLine)== True):
            message.value='Blue dot won!'
        if (purpleDot.hitsShape(finishLine)== True):
            message.value='Purple dot won!'




def onKeyPress(key):
    # Do not change this function! It is for testing purposes only!
    if (key == 'q'):
        message.value = 'Dot Race!'
        purpleDot.centerX = 350
        purpleDot.centerY = 165
        blueDot.centerX = 350
        blueDot.centerY = 240
