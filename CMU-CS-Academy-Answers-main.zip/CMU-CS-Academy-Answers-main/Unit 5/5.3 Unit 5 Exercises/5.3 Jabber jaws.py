app.background = 'lavenderBlush'
app.isMouthGrowing = False

noiseLines = Star(160, 220, 60, 8, roundness=10)
Rect(100, 140, 75, 160, fill='lavenderBlush')

# face
Oval(30, 140, 230, 350, fill='lightSkyBlue')
Polygon(0, 0, 130, 0, 145, 60, 180, 130, 145, 155, 0, 210, fill='lightSkyBlue')
Circle(80, 50, 15)

mouth = Polygon(145, 185, 80, 185, 95, 225, 140, 250, fill='lavenderBlush')
noiseLines.shrink=True

def onKeyHold(keys):
    if(app.isMouthGrowing==True):
        mouth.height+=5
        mouth.width+=5
    if(app.isMouthGrowing==False):
        mouth.height-=5
        mouth.width-=5
    if(mouth.height>=67):
        app.isMouthGrowing=False
    elif(mouth.height<=10):
        app.isMouthGrowing=True
    if(noiseLines.shrink==True):
        noiseLines.radius-=5
    if(noiseLines.shrink==False):
        noiseLines.radius+=5
    if(noiseLines.radius>=65):
        noiseLines.shrink=True
    if(noiseLines.radius<=5):
        noiseLines.shrink=False
    mouth.right=145
    pass
