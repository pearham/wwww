app.background = gradient('black', 'midnightBlue', 'blue', start='left-top')

# background
Polygon(0, 0, 400, 220, 400, 400, 220, 400, fill='white', opacity=30)

# halo and the star
halo = Circle(0, 0, 30, fill=gradient('white', 'gold'), opacity=50)
halo.isGrowing = True

star = Star(0, 0, 1, 5, fill=gradient('lightYellow', 'gold'))

def onKeyHold(keys):
    # Check if the halo is growing and add or subtract accordingly from its size.
    if(halo.isGrowing==True):
        halo.radius+=1
        if(halo.radius>50):
            halo.isGrowing=False
    elif(halo.isGrowing==False):
        halo.radius-=1
        if(halo.radius<20):
            halo.isGrowing=True
            
    if('right'in keys):
        star.centerX+=5
        star.centerY+=5
        star.radius+=1
        star.rotateAngle+=5
        if(star.centerX==400):
            star.centerX=0
            star.centerY=0
            star.radius=1
    halo.centerX=star.centerX
    halo.centerY=star.centerY
