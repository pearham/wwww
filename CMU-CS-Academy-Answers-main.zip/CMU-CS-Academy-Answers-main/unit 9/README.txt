These are the exercises/quizzes missing from UNIT 9:

Minion translator, Super bubbles, Guess the word