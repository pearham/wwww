app.background = 'mediumseaGreen'
app.stepsPerSecond = 20

# glow
rays = Star(200, 200, 175, 25, fill='lemonChiffon', roundness=5, opacity=0)
raysCover = Polygon(130, 165, 270, 165, 200, 285, fill='mediumSeaGreen')

# triforce symbol
top = RegularPolygon(0, -175, 80, 3,
                     fill=gradient('yellow', 'darkGoldenrod', start='right-top'),
                     border='goldenrod', borderWidth=4, rotateAngle=40)
bottomLeft = RegularPolygon(-170, 445, 80, 3,
                            fill=gradient('yellow', 'darkGoldenrod',
                                          start='right-top'),
                            border='goldenrod', borderWidth=4, rotateAngle=40)
bottomRight = RegularPolygon(570, 445, 80, 3,
                             fill=gradient('yellow', 'darkGoldenrod',
                                           start='right-top'),
                             border='goldenrod', borderWidth=4, rotateAngle=80)

def onStep():
    # If the top polygon's centerX is less than 200, then increase
    # its angle and centerX, centerY.
    if (top.centerX < 200):
        top.rotateAngle += 2
        top.centerX += 2
        top.centerY += 3

    if(bottomLeft.centerX<130):
        bottomLeft.rotateAngle+=2
        bottomLeft.centerX+=3
        bottomLeft.centerY-=2
        
    if(bottomRight.centerX>270):
        bottomRight.rotateAngle-=2
        bottomRight.centerX-=3
        bottomRight.centerY-=2
        
    else:
        app.background=gradient('mediumSeaGreen','seaGreen')
        rays.opacity=40
        raysCover.fill=gradient('mediumSeaGreen', 'seaGreen')
    pass
