# four red rectangles
Rect(0, 0, 400, 50, fill='red', opacity=50)
Rect(0, 0, 50, 400, fill='red', opacity=50)
Rect(350, 0, 50, 400, fill='red', opacity=50)
Rect(0, 350, 400, 50, fill='red', opacity=50)

# Draw 4 blue rectangles on top of the red rectangles.
### Place Your Code Here ###
Rect(25, 0, 100, 400, fill='blue', opacity=50)
Rect(0, 25, 400, 100, fill='blue', opacity=50)
Rect(275, 0, 100, 400, fill='blue', opacity=50)
Rect(0, 275, 400, 100, fill='blue', opacity=50)