# Draw two eyes and a mouth to create a serious face.
### (HINT: Use the Inspector to find the left, top, width, and height!)
### Place Your Code Here ###
Rect(100,120,30,80)
Rect(270,120,30,80)
Rect(150,300,100,10)
Rect(180,320,40,20)