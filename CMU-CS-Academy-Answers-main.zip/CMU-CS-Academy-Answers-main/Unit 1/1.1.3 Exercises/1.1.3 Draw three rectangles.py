# Draw three rectangles to match the solution.
### (HINT: Use the Inspector to find the left, top, width, and height!)
### Place Your Code Here ###
Rect(0,200,100,200)
Rect(100,0,300,200)
Rect(200,300,200,100)