# Draw the handle using 4 rectangles and then draw the pick.
### Place Your Code Here ###
Rect(50,50,40,40) #Top
Rect(100,50,200,40) #Left
Rect(50,100,40,200) #Right
Rect(125,125,75,75) #Handle_Top
Rect(200,200,75,75) #Handle_Middle
Rect(275,275,75,75) #Handle_Bottom