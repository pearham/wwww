# Draw two rectangles to match the solution.
### (HINT: Use the Inspector to find the left, top, width, and height!)
### Place Your Code Here ###
Rect(0,200,200,200)
Rect(200,0,200,200)