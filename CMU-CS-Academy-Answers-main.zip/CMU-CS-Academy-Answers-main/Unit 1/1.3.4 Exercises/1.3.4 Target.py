# draw the target
Circle(200, 150, 100, fill='red')
Circle(200, 150, 70, fill='white')
Circle(200, 150, 35, fill='red')

# You are given the target. Use Label to add the name and complete the logo.
### Place Your Code Here ###
Label('TARGET', 200,300, size=65, fill='red', bold=True)





#Label('This is black!', 200, 50, size=36) # default color
#Label('This is blue!', 200, 150, size=36, fill='blue')
#Label('This has a red border!', 200, 250, size=36, fill=None, border='red')
#Label('This has a gradient!', 200, 350, size=36, fill=gradient('blue', 'orange'))