# Draws the Scotty Dog head.
Polygon(130, 60, 150, 140, 150, 70, 170, 130, 260, 130, 220, 150, 325, 160,
        315, 260, 290, 240, 210, 240, 210, 270, 250, 310, 180, 380, 80, 280,
        130, 205)

# Draw the scarf around the neck.
### Place Your Code Here ###
Polygon(80,280,130,205,210,270,250,310, fill='red')