# Draw the background.
### Place Your Code Here ###
Rect(0,0,400,400,fill=rgb(55,225,205))
# Draw the body.
### (HINT: Use two circles and then a rectangle to cover up the bottom half of
#          the circles.)
### Place Your Code Here ###
Circle(200,300,105,fill=rgb(250,200,230))
Circle(200,300,90,fill=rgb(250,220,240))


Rect(95,300,210,100,fill=rgb(55,225,205))
# Then, draw the tentacles and the rest of the face.
### (HINT: Use a circle and then a rectangle to create the mouth.)
### Place Your Code Here ###
Circle(200,265,15,fill=rgb(250,120,180))
Rect(185,250,30,15,fill=rgb(250,220,240))

Circle(155,265,10, fill='black')
Circle(245,265,10, fill='black')
Circle(155,260,5,fill='grey')
Circle(245,260,5,fill='grey')

Rect(120,300,20,80,fill=rgb(250,220,240))
Rect(155,300,20,80,fill=rgb(250,220,240))
Rect(190,300,20,80,fill=rgb(250,220,240))
Rect(225,300,20,80,fill=rgb(250,220,240))
Rect(260,300,20,80,fill=rgb(250,220,240))
# Finally, draw the bubbles!
### Place Your Code Here ###
Circle(120,270,5, opacity=90, fill='white')
Circle(120,240,10, opacity=70, fill='white')
Circle(120,200,20, opacity=50, fill='white')
Circle(120,140,30, opacity=30, fill='white')
Circle(120,60,40, opacity=10, fill='white')
