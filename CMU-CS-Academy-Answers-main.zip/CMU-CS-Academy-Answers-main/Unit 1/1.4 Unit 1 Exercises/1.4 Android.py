# Draw the head.
### Place Your Code Here ###
Line(150,45,200,140, fill=rgb(164,198,57))
Line(250,45,200,140, fill=rgb(164,198,57))
Circle(200,140,80, fill=rgb(164,198,57))
Rect(120,140,160,10, fill='white')
Circle(160,105,5, fill='white')
Circle(240,105,5, fill='white')
# Draw the eyes and then the antennas.
### Place Your Code Here ###

# Draw the main body (with rounded bottom corners).
### Place Your Code Here ###
Rect(120,150,160,120, fill=rgb(164,198,57))
Circle(265,270,15, fill=rgb(164,198,57))
Circle(135,270,15, fill=rgb(164,198,57))
Rect(135,270,130,15,fill=rgb(164,198,57))
# Draw the legs.
### Place Your Code Here ###
Rect(150,285,40,40, fill=rgb(164,198,57))
Rect(210,285,40,40, fill=rgb(164,198,57))
Circle(170,325,20, fill=rgb(164,198,57))
Circle(230,325,20, fill=rgb(164,198,57))
# Draw the arms.
### Place Your Code Here ###
#Left
Rect(70,165,40,80, fill=rgb(164,198,57))
Circle(90,165,20, fill=rgb(164,198,57))
Circle(90,245,20, fill=rgb(164,198,57))
#Right
Rect(290,165,40,80, fill=rgb(164,198,57))
Circle(310,165,20, fill=rgb(164,198,57))
Circle(310,245,20, fill=rgb(164,198,57))
