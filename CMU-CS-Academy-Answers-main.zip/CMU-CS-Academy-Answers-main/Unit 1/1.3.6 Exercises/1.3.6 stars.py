# The circle is provided for you.
Circle(200, 200, 200, fill='lemonChiffon')

# Draw the four stars and use the Inspector to find the roundness values.
### Place Your Code Here ###
Star(200,200,200,6, roundness=80, fill='lightSalmon')
Star(200,200,200,6, roundness=60, fill='lightCyan')
Star(200,200,200,6, roundness=40, fill='lavender')
Star(200,200,200,6, roundness=20, fill='rosyBrown')