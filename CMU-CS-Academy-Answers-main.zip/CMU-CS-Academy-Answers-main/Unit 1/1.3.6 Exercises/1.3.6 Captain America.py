# Create Captain America's shield!
### Place Your Code Here ###
Circle(200,200,150, fill=gradient('red', 'darkRed', start='left'))
Circle(200,200,120, fill=gradient('white', 'darkGrey', start='left'))
Circle(200,200,90, fill=gradient('red', 'darkRed', start='left'))
Circle(200,200,60, fill=gradient('blue', 'darkBlue', start='left'))
Star(200,200,60,5, fill=gradient('white', 'darkGrey', start='left'))
