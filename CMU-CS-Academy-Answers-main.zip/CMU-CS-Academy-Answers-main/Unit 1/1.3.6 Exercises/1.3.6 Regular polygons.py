# Draws a background and the circle on the left.
Rect(0, 0, 400, 400, fill='orchid')
Circle(100, 200, 150, fill='crimson', border='black')

# Draw the polygons.
### Place Your Code Here ###
RegularPolygon(150,200,125,6, border='black', fill='indigo')
RegularPolygon(200,200,100,5, border='black', fill='royalBlue')
RegularPolygon(250,200,75,4, border='black', fill='springGreen')
RegularPolygon(300,200,50,3, border='black', fill='yellow')