# Draw the flag of Ireland!
### (HINT: To draw the border, use Rect with a fill of None and the Inspector to
#          find the borderWidth.)
### Place Your Code Here ###





Rect(50,100,100,200, fill='green')

Rect(250,100,100,200, fill='orange')



Rect(50,100,300,200,fill=None,border='black',borderWidth=5)