# Draw the flag of Sweden. Be sure to use the Inspector!
### Place Your Code Here ###

Rect(50,100,300,200, fill='steelBlue')
Rect(140,100,40,200, fill='gold')
Rect(50,180,300,40, fill='gold')