# Draw the solution image.
### (HINT: There are only two rectangles in the solution and
#          both have gradients!)
### Place Your Code Here ###
Rect(0,300,400,100, fill=gradient("seaGreen", "paleGreen", start="bottom"))
Rect(0,0,400,300, fill=gradient("gold", "skyBlue", "steelBlue"))



#Rect( 40, 50, 70, 70, fill=gradient('red', 'blue', start='left'))